<footer id="box-footer">
	<div class="container">
		<div class="row">
			<div class="footer-inner">
				<div class="box" style="margin-bottom: 0">
                    <p><strong>Mua hàng trực tuyến:</strong> PHPShoppingfree. <strong>Made with:</strong> <i class="fa fa-heart animated infinite pulse" style="color:red"></i> <a href="https://facebook.com/nhim168" title="">@AnDuc</a></p>
                    <p><strong>Địa chỉ Shop:</strong> 29A Ngõ 124 Phố Vĩnh Tuy, Thanh Long, Hai Bà Trưng, Hà Nội.</p>
                    <p><strong>Điện thoại:</strong> 098 9859 3608 &nbsp;&nbsp;&nbsp;<strong>Email:</strong> Hezo.anvu@gmail.com</p>
                </div>
			</div>
		</div>
	</div>
</footer>
</body>
</html>